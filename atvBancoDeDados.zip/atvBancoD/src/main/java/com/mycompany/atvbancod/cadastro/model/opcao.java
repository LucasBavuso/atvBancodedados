package com.mycompany.atvbancod.cadastro.model;
public class opcao {
    
}
